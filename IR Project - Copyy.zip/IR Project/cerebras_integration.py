# From cerebras AI
from cerebras.cloud.sdk import Cerebras
import config   # import config.py (API_KEY_HASH is defined there)

# Decode the hashed API key (original = each value - 1, then convert to char)
_decoded = ""
for num in config.API_KEY_HASH:
    _decoded += chr(num - 1)
API_KEY = _decoded

client = Cerebras(api_key=API_KEY)
MODEL = "llama3.1-8b"

_cerebras_disabled = False

def expand_query_gemini(original_query):
    global _cerebras_disabled
    if _cerebras_disabled:
        return ""
    prompt = f"""
You are a search assistant for a university FAQ system.
The user asked: "{original_query}"
Generate 3 to 5 alternative keywords or short phrases that would also retrieve relevant information.
Return ONLY the keywords separated by spaces, no extra text.
"""
    try:
        completion = client.chat.completions.create(
            messages=[{"role": "user", "content": prompt}],
            model=MODEL,
            max_completion_tokens=1024,
            temperature=0.2,
            top_p=1,
            stream=False
        )
        expanded = completion.choices[0].message.content.strip()
        return expanded
    except Exception as e:
        if "429" in str(e) or "quota" in str(e).lower():
            _cerebras_disabled = True
            print("\n[Cerebras quota exhausted. Disabling AI expansion for this session.]\n")
        else:
            print(f"[Cerebras error: {e}]")
        return ""