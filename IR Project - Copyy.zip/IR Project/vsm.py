import json
import math
import nltk
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

nltk.download('punkt')

def load_stop_words(file_path='stop_list.txt'):
    stop_words = set()
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                word = line.strip().lower()
                if word:
                    stop_words.add(word)
    except FileNotFoundError:
        print("stop_list.txt not found!")
    return stop_words

def preprocess_text(text, stop_words, stemmer):
    text = text.lower()
    tokens = word_tokenize(text)
    filtered = [t for t in tokens if t.isalpha() and t not in stop_words]
    stemmed = [stemmer.stem(t) for t in filtered]
    return stemmed

def load_inverted_index(file_path='inverted_index.json'):
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return {term: set(doc_ids) for term, doc_ids in data.items()}

def load_raw_documents(txt_path='dataset.txt'):
    docs = []
    with open(txt_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split(',', 1)
        if len(parts) != 2:
            continue
        question = parts[0].strip()
        answer = parts[1].strip()
        combined = question + " " + answer
        docs.append(combined)
    return docs

def compute_idf(inverted_index, total_docs):
    idf = {}
    for term, doc_set in inverted_index.items():
        df = len(doc_set)
        idf[term] = math.log(total_docs / (1 + df))
    return idf

def compute_tf(tokens):
    tf = {}
    for t in tokens:
        tf[t] = tf.get(t, 0) + 1
    for t in tf:
        tf[t] = tf[t] / len(tokens) if len(tokens) > 0 else 0
    return tf

# ---------- Compute TF-IDF vector ----------
def compute_tfidf_vector(tf, idf):
    vector = {}
    for term, tf_val in tf.items():
        vector[term] = tf_val * idf.get(term, 0)
    return vector

def cosine_similarity(vec1, vec2):
    terms = set(vec1.keys()) | set(vec2.keys())
    dot_product = 0
    norm1 = 0
    norm2 = 0
    for term in terms:
        v1 = vec1.get(term, 0)
        v2 = vec2.get(term, 0)
        dot_product += v1 * v2
        norm1 += v1 ** 2
        norm2 += v2 ** 2
    if norm1 == 0 or norm2 == 0:
        return 0.0
    return dot_product / (math.sqrt(norm1) * math.sqrt(norm2))

def vsm_search(query_str, inverted_index, idf, raw_docs, stop_words, stemmer):
    query_tokens = preprocess_text(query_str, stop_words, stemmer)
    if not query_tokens:
        return []
    
    query_tf = compute_tf(query_tokens)
    query_vector = compute_tfidf_vector(query_tf, idf)
    
    scores = []
    for doc_id, doc_text in enumerate(raw_docs):
        doc_tokens = preprocess_text(doc_text, stop_words, stemmer)
        doc_tf = compute_tf(doc_tokens)
        doc_vector = compute_tfidf_vector(doc_tf, idf)
        sim = cosine_similarity(query_vector, doc_vector)
        if sim > 0:
            scores.append((doc_id, sim))
    
    scores.sort(key=lambda x: x[1], reverse=True)
    return scores

def get_vsm_results(query_str, inverted_index, idf, raw_docs, stop_words, stemmer):
    return vsm_search(query_str, inverted_index, idf, raw_docs, stop_words, stemmer)  # already 0-based list of (doc_id, score)

def main():
    print("Loading inverted index and documents...")
    inverted_index = load_inverted_index('inverted_index.json')
    raw_docs = load_raw_documents('dataset.txt')
    total_docs = len(raw_docs)
    print(f"Loaded {total_docs} documents and index with {len(inverted_index)} terms.")
    
    idf = compute_idf(inverted_index, total_docs)
    stop_words = load_stop_words('stop_list.txt')
    stemmer = PorterStemmer()
    
    print("\n--- Vector Space Model (TF-IDF + Cosine Similarity) ---")
    while True:
        query = input("\nEnter your query (or 'exit' to quit): ").strip()
        if query.lower() == 'exit':
            break
        if not query:
            continue
        
        results = vsm_search(query, inverted_index, idf, raw_docs, stop_words, stemmer)
        if not results:
            print("No matching documents.")
        else:
            print(f"\nAll {len(results)} matching documents:")
            for i, (doc_id, score) in enumerate(results, 1):
                preview = raw_docs[doc_id][:120].replace('\n', ' ')
                print(f"{i}. [Score: {score:.4f}] Doc {doc_id+1}: {preview}...")
    
    print("Goodbye!")

if __name__ == "__main__":
    main()