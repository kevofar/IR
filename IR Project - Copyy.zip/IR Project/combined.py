
from boolean import load_inverted_index, load_stop_words, get_boolean_results
from vsm import load_raw_documents, compute_idf, get_vsm_results
from nltk.stem import PorterStemmer
from cerebras_integration import expand_query_gemini


print("Loading data...")
inverted_index = load_inverted_index('inverted_index.json')
raw_docs = load_raw_documents('dataset.txt')
stop_words = load_stop_words('stop_list.txt')
stemmer = PorterStemmer()
idf = compute_idf(inverted_index, len(raw_docs))
print(f"Ready. {len(raw_docs)} documents loaded.\n")

while True:
    print("\n1. Boolean (plain)")
    print("2. VSM (plain)")
    print("3. Boolean with GenAI expansion")
    print("4. VSM with GenAI expansion")
    print("5. Exit")
    choice = input("Choose (1, 2, 3, 4 or 5): ").strip()
    if choice == '5':
        break
    if choice not in ('1','2','3','4'):
        print("Invalid choice, TRY AGAIN")
        continue

    query = input("Enter your query: ").strip()
    if not query:
        continue

    
    if choice in ('3','4'):
        print("\nAsking GenAI for keyword expansion...")
        expanded = expand_query_gemini(query)
        if expanded:
            print(f"Cerebas expanded keywords: {expanded}")
            combined_query = query + " " + expanded
        else:
            print("Cerebas expansion failed. Using original query.")
            combined_query = query
    else:
        combined_query = query   

    
    if choice in ('1','3'):
        bool_docs = get_boolean_results(combined_query, inverted_index, stop_words, stemmer)
        print(f"\n--- Boolean results ({len(bool_docs)} documents) ---")
        if bool_docs:
            for doc_id in sorted(bool_docs):
                preview = raw_docs[doc_id][:120].replace('\n', ' ')
                print(f"Doc {doc_id+1}: {preview}...")
        else:
            print("No matching documents.")

    if choice in ('2','4'):
        vsm_results = get_vsm_results(combined_query, inverted_index, idf, raw_docs, stop_words, stemmer)
        print(f"\n--- VSM results ({len(vsm_results)} documents, ranked) ---")
        if vsm_results:
            for rank, (doc_id, score) in enumerate(vsm_results, 1):
                preview = raw_docs[doc_id][:120].replace('\n', ' ')
                print(f"{rank}. Doc {doc_id+1} (score {score:.4f}): {preview}...")
        else:
            print("No matching documents.")

print("Goodbye!")