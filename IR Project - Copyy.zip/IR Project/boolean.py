import json
import nltk
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

nltk.download('punkt')

def load_stop_words(file_path='stop_list.txt'):
    stop_words = set()
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                word = line.strip().lower()
                if word:
                    stop_words.add(word)
    except FileNotFoundError:
        print("stop_list.txt not found!")
    return stop_words

def preprocess_text(text, stop_words, stemmer):
    text = text.lower()
    tokens = word_tokenize(text)
    filtered = [t for t in tokens if t.isalpha() and t not in stop_words]
    stemmed = [stemmer.stem(t) for t in filtered]
    return stemmed

def load_inverted_index(file_path='inverted_index.json'):
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return {term: set(doc_ids) for term, doc_ids in data.items()}

def load_raw_documents(txt_path='dataset.txt'):
    docs = []
    with open(txt_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split(',', 1)
        if len(parts) != 2:
            continue
        question = parts[0].strip()
        answer = parts[1].strip()
        combined = question + " " + answer
        docs.append(combined)
    return docs

def boolean_query_full(query_str, inverted_index, stop_words, stemmer):
    raw_tokens = query_str.strip().split()
    if not raw_tokens:
        return set()
    
    result = None
    current_op = None
    
    for raw in raw_tokens:
        if raw.upper() == 'AND':
            current_op = 'AND'
        elif raw.upper() == 'OR':
            current_op = 'OR'
        elif raw.upper() == 'NOT':
            current_op = 'NOT'
        else:
            term_tokens = preprocess_text(raw, stop_words, stemmer)
            if not term_tokens:
                continue
            term = term_tokens[0]
            term_set = inverted_index.get(term, set())
            if result is None:
                result = term_set.copy()
            else:
                if current_op == 'AND':
                    result.intersection_update(term_set)
                elif current_op == 'OR':
                    result.update(term_set)
                elif current_op == 'NOT':
                    result.difference_update(term_set)
                else:
                    result.intersection_update(term_set)
    return result if result is not None else set()


def get_boolean_results(query_str, inverted_index, stop_words, stemmer):
        result_set = boolean_query_full(query_str, inverted_index, stop_words, stemmer)
        return {doc_id - 1 for doc_id in result_set if doc_id >= 1}   # convert to 0‑based

def main():
    print("Loading inverted index and documents...")
    inverted_index = load_inverted_index('inverted_index.json')
    raw_docs = load_raw_documents('dataset.txt')
    print(f"Loaded {len(raw_docs)} documents, index has {len(inverted_index)} terms.")
    
    stop_words = load_stop_words('stop_list.txt')
    stemmer = PorterStemmer()
    
    print("\n--- Boolean Retrieval Model (AND/OR/NOT) ---")
    print("Example queries: 'RIMS AND password', 'GPA OR dismissal', 'RIMS NOT grade'\n")
    
    while True:
        query = input("Enter Boolean query (or 'exit'): ").strip()
        if query.lower() == 'exit':
            break
        if not query:
            continue
        
        result_set = boolean_query_full(query, inverted_index, stop_words, stemmer)
        result_set_zerobased = {doc_id - 1 for doc_id in result_set if doc_id >= 1}
        print(f"Found {len(result_set_zerobased)} document(s).")
        for doc_id_zb in sorted(result_set_zerobased):
            original_doc_id = doc_id_zb + 1
            preview = raw_docs[doc_id_zb][:120].replace('\n', ' ')
            print(f"  Doc {original_doc_id}: {preview}...")
    
    print("Goodbye!")

if __name__ == "__main__":
    main()