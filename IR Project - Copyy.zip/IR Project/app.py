import os
import sys

# 1. Lock the working directory to the script's location to prevent path issues
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)
print(f"Working directory set to: {os.getcwd()}")

from flask import Flask, render_template, request

# Import your existing models
from boolean import load_inverted_index, load_stop_words, get_boolean_results
from vsm import load_raw_documents, compute_idf, get_vsm_results
from nltk.stem import PorterStemmer

# Gracefully handle the AI integration
try:
    from cerebras_integration import expand_query_gemini
except ImportError:
    print("Warning: cerebras_integration module not found. AI expansion will be disabled.")
    def expand_query_gemini(query):
        return ""

app = Flask(__name__)

# 2. Load the data globally once at startup
print("Loading core data into memory...")
try:
    inverted_index = load_inverted_index('inverted_index.json')
    raw_docs = load_raw_documents('dataset.txt')
    stop_words = load_stop_words('stop_list.txt')
    stemmer = PorterStemmer()
    idf = compute_idf(inverted_index, len(raw_docs))
    print(f"Success: {len(raw_docs)} documents and {len(inverted_index)} terms loaded.")
except Exception as e:
    print(f"CRITICAL ERROR loading base files: {e}")
    inverted_index, raw_docs, stop_words, idf = {}, [], set(), {}
    stemmer = PorterStemmer()

# 3. Helper to load cleanly formatted QA pairs for the frontend
def load_qa_pairs(txt_path='dataset.txt'):
    pairs = []
    try:
        with open(txt_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        # Skip header and safely unpack
        for line in lines[1:]:
            line = line.strip()
            if not line:
                continue
            parts = line.split(',', 1)
            if len(parts) == 2:
                pairs.append((parts[0].strip(), parts[1].strip()))
    except Exception as e:
        print(f"Error loading {txt_path}: {e}")
    return pairs

qa_pairs = load_qa_pairs('dataset.txt')
print(f"Loaded {len(qa_pairs)} QA pairs for display.")

@app.route('/', methods=['GET', 'POST'])
def index():
    results = []
    query = ""
    model = "vsm"
    expanded_query = None
    error = None

    if request.method == 'POST':
        query = request.form.get('query', '').strip()
        model = request.form.get('model', 'vsm')

        if not query:
            error = "Please enter a valid search query."
        else:
            try:
                combined_query = query
                use_ai = model in ('boolean_ai', 'vsm_ai')

                # Handle AI Query Expansion
                if use_ai:
                    print(f"[AI] Requesting expansion for: '{query}'")
                    expanded = expand_query_gemini(query)
                    if expanded:
                        expanded_query = expanded
                        combined_query = f"{query} {expanded}"
                        print(f"[AI] Successfully expanded keywords: {expanded}")
                    else:
                        print("[AI] Expansion failed or returned empty. Using original query.")

                # --- 1. Boolean Retrieval ---
                if model in ('boolean', 'boolean_ai'):
                    bool_set = get_boolean_results(combined_query, inverted_index, stop_words, stemmer)
                    print(f"[DEBUG-BOOL] Engine returned {len(bool_set)} raw doc IDs for '{combined_query}': {bool_set}")
                    
                    for doc_id_0 in sorted(bool_set):
                        if 0 <= doc_id_0 < len(qa_pairs):
                            q_text, a_text = qa_pairs[doc_id_0]
                            results.append({
                                'doc_id': doc_id_0 + 1,
                                'question': q_text,
                                'answer': a_text,
                                'score': None
                            })

                # --- 2. Vector Space Model (VSM) ---
                else: 
                    vsm_list = get_vsm_results(combined_query, inverted_index, idf, raw_docs, stop_words, stemmer)
                    print(f"[DEBUG-VSM] Engine returned {len(vsm_list)} ranked results for '{combined_query}'")
                    
                    for doc_id_0, score in vsm_list[:15]:  # Limit to Top 15 to prevent UI bloat
                        if 0 <= doc_id_0 < len(qa_pairs):
                            q_text, a_text = qa_pairs[doc_id_0]
                            results.append({
                                'doc_id': doc_id_0 + 1,
                                'question': q_text,
                                'answer': a_text,
                                'score': round(score, 4)
                            })
                            
            except Exception as e:
                error = f"An error occurred during search: {str(e)}"
                print(f"[ERROR] {error}")

    return render_template('index.html', 
                           query=query, 
                           model=model, 
                           results=results, 
                           expanded_query=expanded_query, 
                           error=error)

if __name__ == '__main__':
    # Using debug=True will auto-reload the server when you change code
   app.run(debug=False, host='0.0.0.0', port=5000)