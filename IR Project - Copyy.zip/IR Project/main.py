import nltk
import string
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

nltk.download('punkt')


with open('stop_list.txt', 'r', encoding='utf-8') as f:
    stop_words = set(line.strip().lower() for line in f)

stemmer = PorterStemmer()
documents = []

with open('dataset.txt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines[1:], start=1):
    line = line.strip()
    if not line:
        continue
    # Split only at the first comma
    parts = line.split(',', 1)
    if len(parts) != 2:
        continue
    q_raw = parts[0].strip()
    a_raw = parts[1].strip()

    # Preprocess question
    q_tokens = word_tokenize(q_raw.lower())
    q_filtered = [t for t in q_tokens if t not in stop_words and t not in string.punctuation and t.isalpha()]
    q_stemmed = [stemmer.stem(t) for t in q_filtered]

    # Preprocess answer
    a_tokens = word_tokenize(a_raw.lower())
    a_filtered = [t for t in a_tokens if t not in stop_words and t not in string.punctuation and t.isalpha()]
    a_stemmed = [stemmer.stem(t) for t in a_filtered]

    documents.append({
        'doc_id': idx,
        'question_raw': q_raw,
        'answer_raw': a_raw,
        'question_tokens': ' '.join(q_stemmed),
        'answer_tokens': ' '.join(a_stemmed)
    })

with open('processed_data.txt', 'w', encoding='utf-8') as out:
    for doc in documents:
        out.write(f"Doc {doc['doc_id']}\n")
        out.write(f"Q: {doc['question_raw']}\n")
        out.write(f"A: {doc['answer_raw']}\n")
        out.write(f"Q_tokens: {doc['question_tokens']}\n")
        out.write(f"A_tokens: {doc['answer_tokens']}\n")
        out.write("-"*50 + "\n")

print(f"Done. {len(documents)} docs saved to 'processed_data.txt'.")