import json

documents = []
current_doc = {}

with open('processed_data.txt', 'r', encoding='utf-8') as f:
    for line in f:
        line = line.strip()
        if line.startswith('Doc '):
            if current_doc:
                documents.append(current_doc)
            doc_id = int(line.split()[1])
            current_doc = {'doc_id': doc_id}
        elif line.startswith('Q_tokens: '):
            tokens_str = line[10:] 
            current_doc['tokens'] = tokens_str.split()
    if current_doc:
        documents.append(current_doc)

inverted_index = {}
for doc in documents:
    doc_id = doc['doc_id']
    for term in set(doc['tokens']):
        if term not in inverted_index:
            inverted_index[term] = []
        if doc_id not in inverted_index[term]:
            inverted_index[term].append(doc_id)

with open('inverted_index.json', 'w', encoding='utf-8') as out:
    json.dump(inverted_index, out, indent=2)

print(f"Inverted index built with {len(inverted_index)} unique terms.")
print("Saved to inverted_index.json")