
from boolean import load_inverted_index, load_stop_words, get_boolean_results
from vsm import load_raw_documents, compute_idf, get_vsm_results
from nltk.stem import PorterStemmer


print("Loading data...")
inverted_index = load_inverted_index('inverted_index.json')
raw_docs = load_raw_documents('dataset.txt')
stop_words = load_stop_words('stop_list.txt')
stemmer = PorterStemmer()
idf = compute_idf(inverted_index, len(raw_docs))
print(f"Ready. {len(raw_docs)} documents loaded.\n")

while True:
    print("\n1. Boolean retrieval (AND/OR/NOT)")
    print("2. VSM retrieval (TF‑IDF + cosine)")
    print("3. Both models")
    print("4. Exit")
    choice = input("Choose (1/2/3/4): ").strip()
    if choice == '4':
        break
    if choice not in ('1','2','3'):
        print("Invalid choice")
        continue

    query = input("Enter your query: ").strip()
    if not query:
        continue

    # Boolean
    if choice == '1' or choice == '3':
        bool_docs_0based = get_boolean_results(query, inverted_index, stop_words, stemmer)
        print(f"\n--- Boolean results ({len(bool_docs_0based)} documents) ---")
        if bool_docs_0based:
            for doc_id_0 in sorted(bool_docs_0based):
                preview = raw_docs[doc_id_0][:120].replace('\n', ' ')
                print(f"Doc {doc_id_0+1}: {preview}...")
        else:
            print("No matching documents.")

    # VSM
    if choice == '2' or choice == '3':
        vsm_results = get_vsm_results(query, inverted_index, idf, raw_docs, stop_words, stemmer)
        print(f"\n--- VSM results ({len(vsm_results)} documents, ranked) ---")
        if vsm_results:
            for rank, (doc_id_0, score) in enumerate(vsm_results, 1):
                preview = raw_docs[doc_id_0][:120].replace('\n', ' ')
                print(f"{rank}. Doc {doc_id_0+1} (score {score:.4f}): {preview}...")
        else:
            print("No matching documents.")

print("Goodbye!")